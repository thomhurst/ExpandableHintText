# ExpandableHintText
A Pretty EditText for Android
